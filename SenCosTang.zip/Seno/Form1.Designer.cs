﻿
namespace Seno
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txbAngulo = new System.Windows.Forms.TextBox();
            this.lblAngulo = new System.Windows.Forms.Label();
            this.btnCaclular = new System.Windows.Forms.Button();
            this.lblResposta = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txbAngulo
            // 
            this.txbAngulo.Location = new System.Drawing.Point(76, 78);
            this.txbAngulo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txbAngulo.Name = "txbAngulo";
            this.txbAngulo.Size = new System.Drawing.Size(172, 27);
            this.txbAngulo.TabIndex = 0;
            // 
            // lblAngulo
            // 
            this.lblAngulo.AutoSize = true;
            this.lblAngulo.Location = new System.Drawing.Point(66, 44);
            this.lblAngulo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAngulo.Name = "lblAngulo";
            this.lblAngulo.Size = new System.Drawing.Size(196, 19);
            this.lblAngulo.TabIndex = 1;
            this.lblAngulo.Text = "Insira um ângulo até 360º";
            // 
            // btnCaclular
            // 
            this.btnCaclular.Location = new System.Drawing.Point(76, 127);
            this.btnCaclular.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnCaclular.Name = "btnCaclular";
            this.btnCaclular.Size = new System.Drawing.Size(174, 29);
            this.btnCaclular.TabIndex = 2;
            this.btnCaclular.Text = "Calcular";
            this.btnCaclular.UseVisualStyleBackColor = true;
            this.btnCaclular.Click += new System.EventHandler(this.btnCaclular_Click);
            // 
            // lblResposta
            // 
            this.lblResposta.AutoSize = true;
            this.lblResposta.Location = new System.Drawing.Point(76, 177);
            this.lblResposta.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblResposta.Name = "lblResposta";
            this.lblResposta.Size = new System.Drawing.Size(72, 19);
            this.lblResposta.TabIndex = 4;
            this.lblResposta.Text = "Resposta";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(306, 364);
            this.Controls.Add(this.lblResposta);
            this.Controls.Add(this.btnCaclular);
            this.Controls.Add(this.lblAngulo);
            this.Controls.Add(this.txbAngulo);
            this.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txbAngulo;
        private System.Windows.Forms.Label lblAngulo;
        private System.Windows.Forms.Button btnCaclular;
        private System.Windows.Forms.Label lblResposta;
    }
}

