﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Seno.Models;

namespace Seno
{
    class Validacao : absPropriedades 
    {
        public Validacao(string numero) : base(numero)
        {
            this.Executar();
        }
        public override void Executar()
        {
            try
            {
                this.n1 = Convert.ToDouble(this.numero);
                
               resposta = "valido";
                if (this.n1 > 360)
                {
                    resposta = "Angulo maior que 360º";
                }

            }
            catch (Exception)
            {
                resposta="Entrada Inválida";
            }
            mensagem = resposta;
        }
    }
}
