﻿using System;
using Seno.Models;

namespace Seno
{
    public class Calcular : absPropriedades
    {
       public Calcular(Double n1) : base(n1)
        {
            this.Executar();
        }
        public override void Executar()
        {
            //Coss
           cosseno = System.Math.Cos(n1);
            //Seno
           seno = System.Math.Sin(n1);
            //Tangente
           tangente= System.Math.Tan(n1);

            this.resposta = $"Cos{cosseno.ToString().Substring(0, 6)}\nSen {seno.ToString().Substring(0, 6)}\nTang {tangente.ToString().Substring(0, 6)}";
            mensagem = this.resposta;
        }

    }
}
