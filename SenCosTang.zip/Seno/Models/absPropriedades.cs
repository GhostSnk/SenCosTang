﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seno.Models
{

    public abstract class absPropriedades 
    {

       

        public  Double n1 { get; set; }

        protected Double cosseno { get; set; }

        protected string numero { get; set; }

        protected Double seno { get; set; }

        protected Double tangente { get; set; }

        public string mensagem { get; set; }
        protected string resposta { get; set; }

       public absPropriedades(Double n1)
        {
            this.n1 = n1;
           


        }
        public absPropriedades(string numero)
        {
            this.numero = numero;
           
           
        }
       
        public virtual void Executar(){}







    }
}
