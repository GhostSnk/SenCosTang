﻿using System;

using Seno.Models;

namespace Seno
{
    class Controle : absPropriedades 
    {
        public Controle(string numero) : base(numero)
        {
            this.Executar();
        }


        private absPropriedades Start;

        public virtual void Executar()
        {
            Start= new Validacao(numero);

            if (Start.mensagem == "valido") //Dados validos = Calcular
            {
                Start = new Calcular(Convert.ToDouble(numero));
                mensagem = Start.mensagem;
            }
            else //Mensagem de erro
            {
                mensagem = Start.mensagem;
            } 
        }
    }

    }

